# -*- coding: UTF-8 -*-

down = 1
regexSrc = r'(\w+\.jpg)'
path='/home/download/'