# -*- coding: UTF-8 -*-
import os
import uuid
import urllib2
import cookielib
from Log import Log
from MysqlService import MysqlService
import urllib.request


class Application(object):
    
    def __init__(self):
        self.now = datetime.datetime.now()
        self.log = Log(self.now)

    def run(self):
        nowStr=common.datetime_toStringYMDHMS(self.now)
        self.log.printInfo("program start,now:%s" %(nowStr))
        images = self.loadImagesFromMysql()
        print len(images)
        result = self.downloadImages(images)
        self.updateImages(result)
        
    def loadImagesFromMysql(self):
        service = MysqlService(self.log)
        dict = service.getImages()
        return dict
        
    def updateImages(self, images = {}):
        service = MysqlService(self.log)
        service.updateImages(images)
    
    def downloadImages(self, images):
        dict={}
        for (key, value) in dict.items():
            if(self.downloadImage(image)):
                dict["ifdown"] = config.down
                dict["id"] = key
        return dict
        
    def downloadImage(image):
        path, name = self.divideSrc(image['src'])
        url = image['url']   
        #�����ļ�ʱ��ע������Ҫƥ�䣬��Ҫ�����ͼƬΪjpg����򿪵��ļ������Ʊ�����jpg��ʽ������������ЧͼƬ
        data = get_file(url)
        if (data != None):
            save_file(path, name, data)
            return True
        else:
            return False
        
        
    '''��ȡ�ļ���׺��'''
    def get_file_extension(file):  
        return os.path.splitext(file)[1]  

    '''�����ļ�Ŀ¼�������ظ�Ŀ¼'''
    def mkdir(path):
        # ȥ���������ߵĿո�
        path=path.strip()
        # ȥ��β�� \����
        path=path.rstrip("\\")
    
        if not os.path.exists(path):
            os.makedirs(path)
        
        return path

    '''�Զ�����һ��Ψһ���ַ������̶�����Ϊ36'''
    def unique_str():
        return str(uuid.uuid1())

    '''
    ץȡ��ҳ�ļ����ݣ����浽�ڴ�
    
    @url ��ץȡ�ļ� ��path+filename
    '''
    def get_file(url):
        try:
            cj=cookielib.LWPCookieJar()
            opener=urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            urllib2.install_opener(opener)
            
            req=urllib2.Request(url)
            operate=opener.open(req)
            data=operate.read()
            return data
        except BaseException, e:
            print e
            return None

    '''
    �����ļ�������
    
    @path  ����·��
    @file_name �ļ���
    @data �ļ�����
    '''
    def save_file(path, file_name, data):
        if data == None:
            return
    
        mkdir(path)
        if(not path.endswith("/")):
            path=path+"/"
        file=open(path+file_name, "wb")
        file.write(data)
        file.flush()
        file.close()
        
    def divideSrc(src):
        groups = self.regexGroup(src, config.regexSrc)
        name = groups[1]
        path = src.replace(name.strip(), "").strip()
        path = config.path + path
        return path, name
        
    def regexGroup(self, content, regex):
        m = re.search(regex, content,re.M|re.I)
        if m!=None:
            return m.groups()
        else:
            return ()
            
            
if __name__ == '__main__':
    application = Application()
    application.run()